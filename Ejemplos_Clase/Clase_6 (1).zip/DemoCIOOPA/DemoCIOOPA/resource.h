//{{NO_DEPENDENCIES}}
// Archivo de inclusi�n generado de Microsoft Visual C++.
// Usado por DemoCIOOPA.rc
//
#define IDC_MYICON                      2
#define IDD_DEMOCIOOPA_DIALOG           102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_DEMOCIOOPA                  107
#define IDI_SMALL                       108
#define IDC_DEMOCIOOPA                  109
#define IDR_MAINFRAME                   128
#define VET_LOGIN                       129
#define VET_PRINCIPAL                   130
#define LOGIN                           1000
#define REGISTRO                        1001
#define IDC_BUTTON1                     1002
#define PRINCIPAL_MOVER                 1002
#define ID_ARCHIVO_OPCION2              32771
#define ID_OPCION1                      32772
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
